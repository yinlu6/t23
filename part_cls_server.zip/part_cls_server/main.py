from solver.dp_cls_solver import DPSolver

if __name__ == '__main__':
    solver = DPSolver(cfg_path="configs/part_cls.yaml")
    solver.run()
