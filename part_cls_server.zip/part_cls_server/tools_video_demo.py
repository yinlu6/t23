import torch
import yaml
import os
import cv2 as cv
import numpy as np
from PIL import Image
from nets import resnet
from torchvision.transforms import Compose, Resize, CenterCrop, ToTensor, Normalize
import time

basic_transform = Compose([
    Resize(size=256),
    CenterCrop(size=224),
    ToTensor(),
    Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
])


def model_builder(cfg_path="./configs/part_cls.yaml",
                  weight_path="./weights/resnet_cls_9_best.pth"):
    with open(cfg_path, 'r') as rf:
        cfg_model = yaml.safe_load(rf)['model']
    model: torch.nn.Module = getattr(resnet, cfg_model['name'])(pretrained=False,
                                                                num_classes=cfg_model['num_classes'],
                                                                dropout=cfg_model['dropout'],
                                                                reduction=cfg_model['reduction'])
    model.load_state_dict(torch.load(weight_path,map_location="cpu"), strict=False)
    return model

idx_name_map = {
    0: "指肠球部",
    1: "胃体",
    2: "指肠降",
    3: "指肠乳头",
    4: "胃角",
    5: "幽门",
    6: "贲门",
    7: "胃底",
    8: "食管"
}

def file_name(file_dir):
    L = []
    for root, dirs, files in os.walk(file_dir):
        for file in files:
            if os.path.splitext(file)[1].lower() == '.png':
                L.append(os.path.join(root, file).replace('\\','/'))
                # L.append(file)
            elif os.path.splitext(file)[1].lower() == '.jpg':
                L.append(os.path.join(root, file).replace('\\','/'))
                # L.append(file)
            elif os.path.splitext(file)[1].lower() == '.bmp':
                L.append(os.path.join(root, file).replace('\\','/'))
                # L.append(file)
    return L


def cls_predicts_img(model, img, device):
    img_rgb = Image.fromarray(cv.cvtColor(img, cv.COLOR_BGR2RGB))
    img_tensor = basic_transform(img_rgb).unsqueeze(0).to(device)
    predicts = model(img_tensor)[0].argmax().item()
    return predicts


@torch.no_grad()
def read_image(path):
    device = torch.device("cpu") if not torch.cuda.is_available() else torch.device("cuda:0")
    model = model_builder().eval().to(device)
    file_names = file_name(path)
    for file_path in file_names:
        mat = cv.imdecode(np.fromfile(file_path, dtype=np.uint8), -1) #只能用该方法读取含有中文路径的图片
        predict_idx = cls_predicts_img(model, mat, device)
        predict_name = idx_name_map[predict_idx]
        print(file_path, predict_name, predict_idx)


@torch.no_grad()
def read_video(path):
    device = torch.device("cpu") if not torch.cuda.is_available() else torch.device("cuda:0")
    model = model_builder().eval().to(device)
    capture = cv.VideoCapture(path)
    while True:
        ret, frame = capture.read()
        if not ret:
            break
        tic = time.time()
        predict_idx = cls_predicts_img(model, frame, device)
        predict_name = idx_name_map[predict_idx]
        duration = time.time() - tic
        frame = cv.resize(frame, (640, 480))
        cv.putText(frame, "fps:{:4.2f}".format(1 / duration),
                   (10, 20),
                   cv.FONT_HERSHEY_SIMPLEX,
                   .5,
                   (0, 255, 255)
                   , 2)
        cv.imshow(__name__, frame)
        print(predict_name)
        key = cv.waitKey(1)
        if key == ord('q'):
            break


if __name__ == '__main__':
    #read_image("./data")
    read_video(r"D:\QD实时视频录制\stream-allinone.flv")
