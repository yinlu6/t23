# 项目介绍
该项目是基于resnet系列的多分类模型，目前用于内部做部位多分类的任务。

## 项目环境
```text
tqdm
pyyaml
numpy
torch >= 1.5
torchvision >=0.6.0
```
## 性能评估
```shell script
loss:0.309823|top1:89.9225|top3:98.8020
```




## 如何训练
### 1.生成训练数据
1.训练数据文件 train.txt
```text
/home/huffman/data/part_cls_4w/1.食管(4000)G/食管/A768F967.jpg	7
/home/huffman/data/part_cls_4w/2.贲门(4000)G/贲门/AF20EE05.jpg	5
...
```
**单行数据格式如下:图片路径\t图片类别id**

2.测试数据文件 test.txt
```text
格式与训练数据一致
```
3.类别与id的对应关系文件 names.txt
```text
0	指肠球部
1	胃体
2	指肠降部
3	胃角
...
```
**类别id从0开始**

### 2.编辑config目录下的yaml文件
```yaml
model:
  #name:所支持的backbone名称[resnet18,resnet34,resnet50,resnet101,resnet152,
  #     resnext50_32x4d, resnext101_32x8d,wide_resnet50_2, wide_resnet101_2]
  name: resnet50 
  #dropout: 对全链接层进行随机失活的概率 [0, 1)
  dropout: 0.5
  #reduction: 是否对resnet进行squeeze操作【channel attention】
  reduction: False
  #num_classes: 总分类的个数
  num_classes: 8
  #pretrained: 是否进行迁移学习
  pretrained: True

data:
  #train_ann_path: 训练文件的地址
  train_ann_path: data/train.txt
  #test_ann_path: 测试文件的地址
  test_ann_path: data/test.txt
  #upsample: 是否进行上采样
  up_sample: True
  #scale_size: 缩放的目标大小
  scale_size: 256
  #crop_size: 裁减的大小【crop_size必须小于scale_size】
  crop_size: 224
  #batch_size: 单次输入模型的图片个数
  batch_size: 128
  #num_workers: 启用的线程个数
  num_workers: 4

optim:
  #name: 使用的优化器类型 [Adam,SGD]
  name: Adam
  #lr: 初始的学习率
  lr: 0.001
  #weight_decay: 权重衰减程度
  weight_decay: 0.0001
  #momentum: SGD的动量
  momentum: 0.9
  #epoches: 训练的轮数
  epoches: 1
  #milestones: 学习率递减的轮数 [在第15轮🥌，学习率衰减至初始学习率的1/10，第25轮时，学习率衰减至初始学习率的1/100]
  milestones: [15, 25]

val:
  #save_name: 保存模型所用的文件名
  save_name: resnet_cls_8
  #iter_rate: 验证数据并保存权重的频率 [一轮保存一次]
  iter_rate: 1
  #weight_path: 保存权重的路径
  weight_path: weights
#gpus 所使用gpu的编号
gpus: [4,5]

```
## 3.运行main.py
```shell script
python main.py
```
# TODO
- [x] 多卡训练
- [x] 数据增强包含随机裁减、HSV、随机擦除
- [x] 学习率衰减
- [x] top k的准确率计算

# 申明
这是一个baseline，Naive的版本