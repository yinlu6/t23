import os
import yaml
import torch
from torch import nn
from tqdm import tqdm
from nets import resnet
from datasets.naive_dataset import NaiveDataSet
from torch.utils.data.dataloader import DataLoader
from torch.optim.lr_scheduler import MultiStepLR
from utils.helper import AverageLogger
from metrics.cls_metric import cls_tok_acc
from utils.model_utils import rand_seed, ModelEMA
from utils.optims_utils import IterWarmUpCosineDecayMultiStepLRAdjust

rand_seed(1024)


class DPSolver(object):
    def __init__(self, cfg_path):
        with open(cfg_path, 'r') as rf:
            self.cfg = yaml.safe_load(rf)
        self.cfg_model = self.cfg['model']
        self.cfg_data = self.cfg['data']
        self.cfg_val = self.cfg['val']
        self.cfg_optim = self.cfg['optim']

        self.t_data = NaiveDataSet(
            ann_path=self.cfg_data['train_ann_path'],
            up_sample=self.cfg_data['up_sample'],
            augment=True,
            scale_size=self.cfg_data['scale_size'],
            crop_size=self.cfg_data['crop_size']
        )
        self.t_loader = DataLoader(
            dataset=self.t_data,
            batch_size=self.cfg_data['batch_size'],
            num_workers=self.cfg_data['num_workers'],
            shuffle=True,
            drop_last=True
        )

        self.v_data = NaiveDataSet(
            ann_path=self.cfg_data['test_ann_path'],
            up_sample=False,
            augment=False,
            scale_size=self.cfg_data['scale_size'],
            crop_size=self.cfg_data['crop_size']
        )
        self.v_loader = DataLoader(
            dataset=self.v_data,
            batch_size=self.cfg_data['batch_size'],
            num_workers=self.cfg_data['num_workers'],
            shuffle=False,
            drop_last=False
        )
        model: torch.nn.Module = getattr(resnet, self.cfg_model['name'])(pretrained=self.cfg_model['pretrained'],
                                                                         num_classes=self.cfg_model['num_classes'],
                                                                         dropout=self.cfg_model['dropout'],
                                                                         reduction=self.cfg_model['reduction'])

        print("train_data: ", len(self.t_data), " | ", "test_data: ", len(self.v_data))
        if self.cfg_optim['name'] == "SGD":
            self.optimizer = torch.optim.SGD(
                params=model.parameters(),
                lr=self.cfg_optim['lr'],
                weight_decay=self.cfg_optim['weight_decay'],
                momentum=self.cfg_optim['momentum']
            )
        elif self.cfg_optim['name'] == "Adam":
            self.optimizer = torch.optim.Adam(
                params=model.parameters(),
                lr=self.cfg_optim['lr'],
                weight_decay=self.cfg_optim['weight_decay']
            )
        else:
            raise NotImplementedError("only support SGD and Adam now!")
        self.lr_scheduler = MultiStepLR(self.optimizer,
                                        milestones=self.cfg_optim['milestones']
                                        )
        # self.lr_scheduler = IterWarmUpCosineDecayMultiStepLRAdjust(
        #     init_lr=self.cfg_optim['lr'],
        #     milestones=self.cfg_optim['milestones'],
        #     warm_up_epoch=1,
        #     iter_per_epoch=len(self.t_loader),
        #     epochs=self.cfg_optim['epoches']
        # )
        assert torch.cuda.is_available(), "training only support cuda"
        assert torch.cuda.device_count() >= len(self.cfg['gpus']), "not have enough gpus"
        self.inp_device = torch.device("cuda:{:d}".format(self.cfg['gpus'][0]))
        self.out_device = torch.device("cuda:{:d}".format(self.cfg['gpus'][-1]))
        model.to(self.inp_device)
        # if self.optim_cfg['sync_bn']:
        #     model = nn.SyncBatchNorm.convert_sync_batchnorm(model)
        self.model = nn.DataParallel(
            model, device_ids=self.cfg['gpus'], output_device=self.out_device)
        # self.ema = ModelEMA(self.model)
        self.tok_1_logger = AverageLogger()
        self.tok_3_logger = AverageLogger()
        self.loss_logger = AverageLogger()
        self.creterion = nn.CrossEntropyLoss()
        self.best_acc = 0.0

    def train(self, epoch):
        self.model.train()
        self.tok_1_logger.reset()
        self.tok_3_logger.reset()
        self.loss_logger.reset()
        pbar = tqdm(self.t_loader)
        for i, (input_img, targets) in enumerate(pbar):
            input_img = input_img.to(self.inp_device)
            targets = targets.to(self.out_device)
            predicts = self.model(input_img)
            loss = self.creterion(predicts, targets)
            self.optimizer.zero_grad()
            loss.backward()
            # self.lr_scheduler(self.optimizer, i, epoch)
            self.optimizer.step()

            match_num1, batch_num = cls_tok_acc(predicts.detach(), targets, 1)
            self.tok_1_logger.update(match_num1, batch_num)
            match_num3, _ = cls_tok_acc(predicts.detach(), targets, 3)
            self.tok_3_logger.update(match_num3, batch_num)
            self.loss_logger.update(loss.item())
            # self.ema.update(self.model)
            lr = self.optimizer.param_groups[0]['lr']
            pbar.set_description(
                "train epoch:{:3d}|iter:{:4d}|loss:{:8.6f}|top1:{:6.4f}|top3:{:6.4f}|lr:{:8.6f}".format(
                    epoch + 1,
                    i,
                    self.loss_logger.avg(),
                    self.tok_1_logger.avg() * 100,
                    self.tok_3_logger.avg() * 100,
                    lr
                ))
        # self.ema.update_attr(self.model)
        self.lr_scheduler.step()

    @torch.no_grad()
    def val(self, epoch):
        self.model.eval()
        self.tok_1_logger.reset()
        self.tok_3_logger.reset()
        self.loss_logger.reset()
        pbar = tqdm(self.v_loader)
        for i, (input_img, targets) in enumerate(pbar):
            input_img = input_img.to(self.inp_device)
            targets = targets.to(self.out_device)
            predicts = self.model(input_img)
            loss = self.creterion(predicts, targets)
            match_num1, batch_num = cls_tok_acc(predicts.detach(), targets, 1)
            self.tok_1_logger.update(match_num1, batch_num)
            match_num3, _ = cls_tok_acc(predicts.detach(), targets, 3)
            self.tok_3_logger.update(match_num3, batch_num)
            self.loss_logger.update(loss.item())
            pbar.set_description(
                "val epoch:{:3d}|iter:{:4d}|loss:{:8.6f}|top1:{:6.4f}|top3:{:6.4f}".format(
                    epoch + 1,
                    i,
                    self.loss_logger.avg(),
                    self.tok_1_logger.avg() * 100,
                    self.tok_3_logger.avg() * 100,
                ))

        if self.tok_1_logger.avg() > self.best_acc:
            self.best_acc = self.tok_1_logger.avg()
            best_path = os.path.join(self.cfg_val['weight_path'],
                                     "{:s}_{:d}_best.pth"
                                     .format(self.cfg_val['save_name'], self.cfg_model['num_classes']))
            torch.save(self.model.module.state_dict(), best_path)
        last_path = os.path.join(self.cfg_val['weight_path'],
                                 "{:s}_{:d}_last.pth"
                                 .format(self.cfg_val['save_name'], self.cfg_model['num_classes']))
        torch.save(self.model.module.state_dict(), last_path)

    def run(self):
        for epoch in range(self.cfg_optim['epoches']):
            self.train(epoch)
            if (epoch + 1) % self.cfg_val['iter_rate'] == 0:
                self.val(epoch)
