import sys
import os
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
import cv2
import numpy as np
from threading import Thread
import time
from PicManTool_Main_UI import Ui_Form
import torch
import yaml
import os
from PIL import Image
from PIL import ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True
from nets import resnet
from torchvision.transforms import Compose, Resize, CenterCrop, ToTensor, Normalize
import pymysql

basic_transform = Compose([
    Resize(size=256),
    CenterCrop(size=224),
    ToTensor(),
    Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
])

def SelectPathIfExist(file):
    bFound = False
    try:
        conn = pymysql.connect(host="10.0.99.103", user="root", passwd="P@ssw0rd", database="picmantool", charset="utf8")
        cur = conn.cursor()
        sql = "select Path from picstordes where Path = '{}'".format(file)
        select = cur.execute(sql)
        if cur.rownumber > 0:
            bFound = True
        cur.close()
        conn.commit()
        conn.close()
    except Exception as error:
        print('查询数据失败: '+ error + '\n')
    finally:
        pass
    return bFound

def InsertRecordToDb(file):
    try:
        conn = pymysql.connect(host="10.0.99.103", user="root", passwd="P@ssw0rd", database="picmantool", charset="utf8")
        cur = conn.cursor()
        sql = "insert into picstordes(Path,Width,Height)values('{}',{},{})".format(file,1000,1000)
        insert = cur.execute(sql)
        cur.close()
        conn.commit()
        conn.close()
    except Exception as error:
        print('插入数据失败: '+ error + '\n')
    finally:
        pass

def UpdateRecordToDb(file):
    try:
        conn = pymysql.connect(host="10.0.99.103", user="root", passwd="P@ssw0rd", database="picmantool", charset="utf8")
        cur = conn.cursor()
        sql = "update picstordes set Width = {},Height = {} where Path = '{}')".format(2000,2000,file)
        update = cur.execute(sql)
        cur.close()
        conn.commit()
        conn.close()
    except Exception as error:
        print('更新数据失败: '+ error + '\n')
    finally:
        pass

def model_builder(cfg_path="./configs/part_cls.yaml",
                  weight_path="./weights/resnet_cls_9_best.pth"):
    with open(cfg_path, 'r') as rf:
        cfg_model = yaml.safe_load(rf)['model']
    model: torch.nn.Module = getattr(resnet, cfg_model['name'])(pretrained=False,
                                                                num_classes=cfg_model['num_classes'],
                                                                dropout=cfg_model['dropout'],
                                                                reduction=cfg_model['reduction'])
    model.load_state_dict(torch.load(weight_path,map_location="cpu"), strict=False)
    return model


def cls_predicts_func(model, img_path, device):
    img_rgb = Image.open(img_path).convert('RGB')
    img_tensor = basic_transform(img_rgb).unsqueeze(0).to(device)
    predicts = model(img_tensor)[0].softmax(dim=-1)
    val, idx = predicts.max(), predicts.argmax()
    return val, idx


class Main(QMainWindow, Ui_Form):
    signal_startproc = pyqtSignal(str)

    def __init__(self):
        super(Main, self).__init__()
        self.setupUi(self)
        self.initui()

    def initui(self):
        self.threadrunning = True
        #self.imglist = []
        self.signal_startproc.connect(self.StartProcFun)
        self.pushButton.pressed.connect(self.Start)
        self.toolButton.pressed.connect(self.filechoose1)
        self.toolButton_2.pressed.connect(self.filechoose2)
        self.lineEdit_2.setText('C:')
        self.lineEdit_11.setText('10')
        self.textEdit.setText("")
        self.lineEdit_12.setText('0.65')

    def StartProcFun(self,str):
        QMessageBox.information(self,'提示！',str)

    def Start(self):
        self.imglist = self.file_name(self.lineEdit.text())
        self.signal_startproc.emit('本次执行检索到 ' + str(len(self.imglist)) + ' 张图像!\n')
        print('本次执行检索到 ' + str(len(self.imglist)) + ' 张图像!\n')
        self.textEdit.clear()
        if len(self.imglist) > 0:
            self.label_4.setText('分类进行中!!!')
            thread = Thread(target=self.threadfunc)
            thread.start()

    def threadfunc(self):
        device = torch.device("cpu") if not torch.cuda.is_available() else torch.device("cuda:0")
        model = model_builder().eval().to(device)
        idx_name_map = {
            0: "指肠球部",
            1: "胃体",
            2: "指肠降",
            3: "指肠乳头",
            4: "胃角",
            5: "幽门",
            6: "贲门",
            7: "胃底",
            8: "食管"
        }





        if len(self.imglist) > 0:
            with open(self.lineEdit_2.text() + '/' + "图片分拣记录.txt", "a") as f:
                for filepath in self.imglist:
                    # str = self.imglist[0]
                    print(filepath)
                    try:
                        mat = cv2.imdecode(np.fromfile(filepath, dtype=np.uint8), -1) #只能用该方法读取含有中文路径的图片
                        height, width, depth = mat.shape  # 获取图像的高，宽以及深度。
                    except:
                        self.label_4.setText("文件打开失败: "+filepath)
                        continue
                    else:
                        pass
                    if mat is None:
                        self.label_4.setText("文件打开失败: "+filepath)
                        continue
                    if width <= 0 or height <= 0:
                        self.label_4.setText("文件打开失败: "+filepath)
                        continue

                    dir, file = os.path.split(filepath)
                    val, idx = cls_predicts_func(model, filepath, device)
                    predict_name = idx_name_map[idx.item()]
                    strpath = self.lineEdit_2.text() + '/' + predict_name + '/' + file
                    dir, file = os.path.split(strpath)
                    if not os.path.exists(dir):
                        os.makedirs(dir)
                    #print(strpath)
                    if float(val.item())>=float(self.lineEdit_12.text()):
                        print(filepath, predict_name, val.item())
                        self.textEdit.append(filepath+" "+predict_name+" "+str(val.item()))
                        #cv2.imwrite(strpath, mat) #仅限于纯英文路径
                        cv2.imencode('.jpg', mat)[1].tofile(strpath)  #英文或中文路径均适用
                        f.writelines(strpath+"\n")

                    mat = cv2.cvtColor(mat, cv2.COLOR_BGR2RGB)
                    height, width, depth = mat.shape  # 获取图像的高，宽以及深度。
                    qimg = QImage(mat.data, width, height, depth * width, QImage.Format_RGB888)
                    self.label.setPixmap(QPixmap.fromImage(qimg))
                    bFound = SelectPathIfExist(filepath)
                    if not bFound:
                        InsertRecordToDb(filepath)
                    else:
                        UpdateRecordToDb(filepath)
                    if not self.threadrunning:
                        break
                    time.sleep(int(self.lineEdit_11.text()) / 1000)
        self.label_4.setText('分类结束!!!')

    def file_name(self,file_dir):
        L = []
        for root, dirs, files in os.walk(file_dir):
            for file in files:
                if os.path.splitext(file)[1].lower() == '.png':
                    L.append(os.path.join(root, file).replace('\\', '/'))
                    # L.append(file)
                elif os.path.splitext(file)[1].lower() == '.jpg':
                    L.append(os.path.join(root, file).replace('\\', '/'))
                    # L.append(file)
                elif os.path.splitext(file)[1].lower() == '.bmp':
                    L.append(os.path.join(root, file).replace('\\', '/'))
                    # L.append(file)
        return L

    def filechoose1(self):
        dir_choose = QFileDialog.getExistingDirectory(self, "选取文件夹")
        if dir_choose == "":
            return
        self.lineEdit.setText(dir_choose)

    def filechoose2(self):
        dir_choose = QFileDialog.getExistingDirectory(self, "选取文件夹")
        if dir_choose == "":
            return
        self.lineEdit_2.setText(dir_choose)

    def closeEvent(self, event):
        # 创建一个消息盒子（提示框）
        quitMsgBox = QMessageBox()
        # 设置提示框的标题
        quitMsgBox.setWindowTitle('确认提示')
        # 设置提示框的内容
        quitMsgBox.setText('你确认退出吗？')
        # 设置按钮标准，一个yes一个no
        quitMsgBox.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        # 获取两个按钮并且修改显示文本
        buttonY = quitMsgBox.button(QMessageBox.Yes)
        buttonY.setText('确定')
        buttonN = quitMsgBox.button(QMessageBox.No)
        buttonN.setText('取消')
        quitMsgBox.exec_()
        # 判断返回值，如果点击的是Yes按钮，我们就关闭组件和应用，否则就忽略关闭事件
        if quitMsgBox.clickedButton() == buttonY:
            event.accept()
            self.threadrunning = False
        else:
            event.ignore()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    win = Main()
    win.show()
    sys.exit(app.exec())
