import os
import numpy as np
from PIL import Image
from tqdm import tqdm


def traver_file_reader(base_path, read_in_list, cls_idx):
    for file_name in os.listdir(base_path):
        file_path = os.path.join(base_path, file_name)
        if os.path.isfile(file_path) and file_path.endswith(".jpg"):
            try:
                img_rgb = Image.open(file_path)
            except Exception as e:
                print(e)
                continue
            read_in_list.append((file_path, cls_idx))
        elif os.path.isdir(file_path):
            traver_file_reader(file_path, read_in_list, cls_idx)
        else:
            continue


def read_in_data(base_path):
    dir_names = os.listdir(base_path)
    data_list = list()
    idx_name_map = dict()
    for i, dir_name in tqdm(enumerate(dir_names)):
        traver_file_reader(os.path.join(base_path, dir_name), data_list, i)
        idx_name_map[i] = dir_name
    print(len(idx_name_map.items()))
    return data_list, idx_name_map


def train_test_split(data_list, ratio=0.92):
    data_np = np.array(data_list)
    np.random.shuffle(data_np)
    split_idx = int(len(data_np) * ratio)
    train_data = data_np[:split_idx]
    test_data = data_np[split_idx:]
    return train_data, test_data


def read_in_main():
    data_list, idx_name_map = read_in_data("/home/huffman/data/part_cls_4w")
    train_data, test_data = train_test_split(data_list)
    with open("../data/train.txt", "w") as wf:
        for item in train_data:
            print("{:s}\t{:d}".format(item[0], int(item[1])), file=wf)
    with open("../data/test.txt", "w") as wf:
        for item in test_data:
            print("{:s}\t{:d}".format(item[0], int(item[1])), file=wf)
    with open("../data/names.txt", 'w') as wf:
        for k, v in idx_name_map.items():
            print("{:d}\t{:s}".format(k, v), file=wf)


if __name__ == '__main__':
    read_in_main()
