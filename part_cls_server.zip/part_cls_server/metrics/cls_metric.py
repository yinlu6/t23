import torch


def cls_acc(predicts: torch.Tensor, targets: torch.Tensor):
    """
    :param predicts: [bs,cls_num]
    :param targets:  [bs]
    :return:
    """
    predicts_cls = predicts.argmax(dim=-1)
    equal_num = (predicts_cls.long() == targets).sum()
    return equal_num.item(), predicts.shape[0]


def cls_tok_acc(predicts: torch.Tensor, targets: torch.Tensor, k: int = 3):
    """
    :param predicts: [bs, cls_num]
    :param targets: [bs]
    :param k:
    :return:
    """
    _, idx = predicts.topk(dim=-1, k=k)
    predict_mask = torch.zeros_like(predicts).scatter(dim=-1, index=idx, value=1.)
    target_mask = torch.zeros_like(predicts).scatter(dim=-1, index=targets[:, None], value=1.)
    match_num = (predict_mask.bool() & target_mask.bool()).sum().item()
    return match_num, predicts.shape[0]
