import torch
import yaml
import os
from PIL import Image
from nets import resnet
from torchvision.transforms import Compose, Resize, CenterCrop, ToTensor, Normalize

basic_transform = Compose([
    Resize(size=256),
    CenterCrop(size=224),
    ToTensor(),
    Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
])


def model_builder(cfg_path="./configs/part_cls.yaml",
                  weight_path="./weights/resnet_cls_9_best.pth"):
    with open(cfg_path, 'r') as rf:
        cfg_model = yaml.safe_load(rf)['model']
    model: torch.nn.Module = getattr(resnet, cfg_model['name'])(pretrained=False,
                                                                num_classes=cfg_model['num_classes'],
                                                                dropout=cfg_model['dropout'],
                                                                reduction=cfg_model['reduction'])
    model.load_state_dict(torch.load(weight_path,map_location="cpu"), strict=False)
    return model


def cls_predicts_func(model, img_path, device):
    img_rgb = Image.open(img_path)
    img_tensor = basic_transform(img_rgb).unsqueeze(0).to(device)
    predicts = model(img_tensor)[0].softmax(dim=-1)
    val, idx = predicts.max(), predicts.argmax()
    return val, idx


def file_name(file_dir):
    L = []
    for root, dirs, files in os.walk(file_dir):
        for file in files:
            if os.path.splitext(file)[1].lower() == '.png':
                L.append(os.path.join(root, file).replace('\\','/'))
                # L.append(file)
            elif os.path.splitext(file)[1].lower() == '.jpg':
                L.append(os.path.join(root, file).replace('\\','/'))
                # L.append(file)
            elif os.path.splitext(file)[1].lower() == '.bmp':
                L.append(os.path.join(root, file).replace('\\','/'))
                # L.append(file)
    return L


@torch.no_grad()
def demo():
    device = torch.device("cpu") if not torch.cuda.is_available() else torch.device("cuda:0")
    model = model_builder().eval().to(device)
    idx_name_map = {
        0: "指肠球部",
        1: "胃体",
        2: "指肠降",
        3: "指肠乳头",
        4: "胃角",
        5: "幽门",
        6: "贲门",
        7: "胃底",
        8: "食管"
    }
    file_names = file_name("./data")
    for file_path in file_names:
        val, idx = cls_predicts_func(model, file_path, device)
        predict_name = idx_name_map[idx.item()]
        print(file_path, predict_name, val.item())


if __name__ == '__main__':
    demo()
