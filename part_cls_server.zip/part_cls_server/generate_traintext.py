import os

idx_name_map = {
    0: "指肠球部",
    1: "胃体",
    2: "指肠降",
    3: "指肠乳头",
    4: "胃角",
    5: "幽门",
    6: "贲门",
    7: "胃底",
    8: "食管"
}

def file_name(file_dir):
    L = []
    for root, dirs, files in os.walk(file_dir):
        for file in files:
            if os.path.splitext(file)[1].lower() == '.png':
                L.append(os.path.join(root, file).replace('\\','/'))
                # L.append(file)
            elif os.path.splitext(file)[1].lower() == '.jpg':
                L.append(os.path.join(root, file).replace('\\','/'))
                # L.append(file)
            elif os.path.splitext(file)[1].lower() == '.bmp':
                L.append(os.path.join(root, file).replace('\\','/'))
                # L.append(file)
    return L

def demo():
    with open("./data/train.txt","w") as f:
        file_names = file_name("./data")
        for file in file_names:
            print(file)
            for type in idx_name_map:
                name = idx_name_map[type]
                if file.find(name)!=-1:
                    f.write(file+"\t"+str(type))
                    f.write("\n")

if __name__ == '__main__':
    demo()
