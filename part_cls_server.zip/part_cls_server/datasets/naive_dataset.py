import os
import torch
import numpy as np
from PIL import Image
from torch.utils.data.dataset import Dataset
from torchvision.transforms import Compose, ColorJitter, CenterCrop, RandomApply, \
    RandomCrop, RandomHorizontalFlip, RandomVerticalFlip, RandomErasing, Normalize, ToTensor, Resize, RandomAffine


class NaiveDataSet(Dataset):
    def __init__(self, ann_path, scale_size=256, crop_size=224, augment=True, up_sample=True):
        self.ann_path = ann_path
        self.scale_size = scale_size
        self.crop_size = crop_size
        self.augment = augment
        self.up_sample = up_sample
        self.transform = None
        if self.augment:
            self.transform = Compose([
                ColorJitter(brightness=0.3, contrast=0.2, saturation=0.2, hue=0.1),
                Resize(size=scale_size),
                RandomApply(transforms=[RandomAffine(
                    degrees=45, translate=(0.15, 0.15), scale=(0.8, 1.2))]),
                RandomCrop(size=crop_size),
                RandomHorizontalFlip(),
                RandomVerticalFlip(),
                ToTensor(),
                Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225)),
                # RandomErasing(scale=(0.02, 0.2))
            ])
        else:
            self.transform = Compose([
                Resize(size=scale_size),
                CenterCrop(size=crop_size),
                ToTensor(),
                Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
            ])
        self.data_list = list()
        self.__read_in_data()
        if self.up_sample:
            self.__data_up_sample()

    def __read_in_data(self):
        with open(self.ann_path) as rf:
            data_list = rf.readlines()
        for item in data_list:
            if item.split() == "":
                continue
            data_item = item.strip().split()
            self.data_list.append((data_item[0], int(data_item[1])))

    def __data_up_sample(self):

        def up_sample(data, sample_num):
            sample_num = sample_num - len(data)
            if sample_num <= 0:
                return data
            append_data = np.random.choice(data, size=sample_num, replace=True).tolist()
            data.extend(append_data)
            return data

        data_groups = dict()
        for path, idx in self.data_list:
            group_list = data_groups.get(idx, list())
            group_list.append(path)
            data_groups[idx] = group_list
        max_len = max([len(v) for k, v in data_groups.items()])

        ret_data_list = list()
        for k, v in data_groups.items():
            sample_data = up_sample(v, max_len)
            for path in sample_data:
                ret_data_list.append((path, int(k)))
        np.random.shuffle(ret_data_list)
        self.data_list = ret_data_list

    def __getitem__(self, item):
        img_path, idx = self.data_list[item]
        img_rgb = Image.open(img_path)
        img_tensor = self.transform(img_rgb)
        return img_tensor, torch.tensor(data=idx, dtype=torch.long)

    def __len__(self):
        return len(self.data_list)


if __name__ == '__main__':
    from torch.utils.data.dataloader import DataLoader

    data_set = NaiveDataSet(ann_path="../data/train.txt", up_sample=False)

    loader = DataLoader(dataset=data_set, batch_size=16, shuffle=True, num_workers=4)
    for img_input, target in loader:
        print(img_input.shape, target.shape)
        break
